// IndexedDB wrapper for Shoe Store
const DB_NAME = 'ShoeStoreDB';
const DB_VERSION = 1;

const SIZES = [36, 37, 38, 39, 40, 41, 42, 43, 44, 45];

class StoreDB {
  constructor() {
    this.db = null;
  }

  async init() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve();
      };

      request.onupgradeneeded = (e) => {
        const db = e.target.result;

        if (!db.objectStoreNames.contains('products')) {
          const store = db.createObjectStore('products', { keyPath: 'id', autoIncrement: true });
          store.createIndex('name', 'name', { unique: false });
        }

        if (!db.objectStoreNames.contains('sales')) {
          const store = db.createObjectStore('sales', { keyPath: 'id', autoIncrement: true });
          store.createIndex('date', 'date', { unique: false });
        }
      };
    });
  }

  // ---------- PRODUCTS ----------

  async addProduct(product) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction('products', 'readwrite');
      const store = tx.objectStore('products');
      const req = store.add(product);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async updateProduct(product) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction('products', 'readwrite');
      const store = tx.objectStore('products');
      const req = store.put(product);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async deleteProduct(id) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction('products', 'readwrite');
      const store = tx.objectStore('products');
      const req = store.delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async getProduct(id) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction('products', 'readonly');
      const store = tx.objectStore('products');
      const req = store.get(id);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async getAllProducts() {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction('products', 'readonly');
      const store = tx.objectStore('products');
      const req = store.getAll();
      req.onsuccess = () => {
        const list = req.result || [];
        list.sort((a, b) => a.name.localeCompare(b.name, 'ru'));
        resolve(list);
      };
      req.onerror = () => reject(req.error);
    });
  }

  // ---------- SALES ----------

  async addSale(sale) {
    // Decrease stock first
    for (const item of sale.items) {
      const product = await this.getProduct(item.productId);
      if (!product) throw new Error('Товар не найден');
      const current = product.sizes[item.size] || 0;
      if (current < item.quantity) {
        throw new Error(`Недостаточно остатка: ${product.name} р.${item.size}`);
      }
      product.sizes[item.size] = current - item.quantity;
      await this.updateProduct(product);
    }

    return new Promise((resolve, reject) => {
      const tx = this.db.transaction('sales', 'readwrite');
      const store = tx.objectStore('sales');
      const req = store.add(sale);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async cancelSale(saleId) {
    const sale = await this.getSale(saleId);
    if (!sale || sale.cancelled) return;

    // Restore stock
    for (const item of sale.items) {
      const product = await this.getProduct(item.productId);
      if (product) {
        product.sizes[item.size] = (product.sizes[item.size] || 0) + item.quantity;
        await this.updateProduct(product);
      }
    }

    sale.cancelled = true;
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction('sales', 'readwrite');
      const store = tx.objectStore('sales');
      const req = store.put(sale);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async getSale(id) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction('sales', 'readonly');
      const store = tx.objectStore('sales');
      const req = store.get(id);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async getAllSales() {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction('sales', 'readonly');
      const store = tx.objectStore('sales');
      const req = store.getAll();
      req.onsuccess = () => {
        const list = req.result || [];
        list.sort((a, b) => new Date(b.date) - new Date(a.date));
        resolve(list);
      };
      req.onerror = () => reject(req.error);
    });
  }

  // ---------- REPORTS ----------

  async getReport(from, to) {
    const sales = await this.getAllSales();
    const filtered = sales.filter(s => {
      if (s.cancelled) return false;
      const d = new Date(s.date);
      return d >= from && d <= to;
    });

    let totalAmount = 0;
    let totalProfit = 0;
    let itemsCount = 0;

    filtered.forEach(s => {
      totalAmount += s.totalAmount;
      totalProfit += s.totalProfit;
      s.items.forEach(i => itemsCount += i.quantity);
    });

    return {
      totalAmount,
      totalProfit,
      salesCount: filtered.length,
      itemsCount
    };
  }

  async getTopProducts(from, to, limit = 10) {
    const sales = await this.getAllSales();
    const map = {};

    sales.forEach(s => {
      if (s.cancelled) return;
      const d = new Date(s.date);
      if (d < from || d > to) return;

      s.items.forEach(item => {
        const key = `${item.productId}_${item.size}`;
        if (!map[key]) {
          map[key] = {
            productName: item.productName,
            size: item.size,
            totalQty: 0,
            totalAmount: 0,
            totalProfit: 0
          };
        }
        map[key].totalQty += item.quantity;
        map[key].totalAmount += item.sellPrice * item.quantity;
        map[key].totalProfit += (item.sellPrice - item.purchasePrice) * item.quantity;
      });
    });

    return Object.values(map)
      .sort((a, b) => b.totalQty - a.totalQty)
      .slice(0, limit);
  }

  // ---------- BACKUP ----------

  async exportData() {
    const products = await this.getAllProducts();
    const sales = await this.getAllSales();
    return { products, sales, exportedAt: new Date().toISOString(), version: 1 };
  }

  async importData(data) {
    if (!data.products || !data.sales) throw new Error('Неверный формат файла');

    // Clear existing
    await this.clearStore('products');
    await this.clearStore('sales');

    for (const p of data.products) {
      // Remove id to let autoIncrement work, or keep if present
      const { id, ...rest } = p;
      await this.addProduct(rest);
    }

    // For sales we need to be careful with IDs, but for simplicity re-add
    for (const s of data.sales) {
      const { id, ...rest } = s;
      await new Promise((resolve, reject) => {
        const tx = this.db.transaction('sales', 'readwrite');
        const store = tx.objectStore('sales');
        const req = store.add(rest);
        req.onsuccess = () => resolve();
        req.onerror = () => reject(req.error);
      });
    }
  }

  clearStore(name) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(name, 'readwrite');
      const store = tx.objectStore(name);
      const req = store.clear();
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }
}

const db = new StoreDB();
